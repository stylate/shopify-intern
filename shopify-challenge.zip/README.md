# Shopify Backend Intern Challenge - Summer 2018

Running main.py will generate an appropriate JSON file named output. The solution is spread out amongst `main.py`, `menu.py`, `shopify_tree.py`, and `treemap.py`.

The link to the challenge is [here](http://backend-challenge-summer-2018.herokuapp.com/), but in case that the link expires, then the challenge is shown in a local file named `index.html`.

